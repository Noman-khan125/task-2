import React from 'react';
import "./App.css"
import { useState } from 'react';
import { useSelector,useDispatch} from 'react-redux';
import Input from "./components/Input"
import { incNumber, decNumber} from './action/index';
import calcualate from './components/calcualate';
import enput from './components/enput';
// import  Store from './reducers/store'
import Stori from './components/stori'
//  import CalculationOverview from'./components/redux/calculationOverview'
// import store1 from './components/redux/store1';
import i from './components/i';
const App = () => {
  const myState = useSelector((state)=>state.changeTheNumber);
  const dispatch = useDispatch( );
  return (
    <>
    
      <div className='container'>
        <h1>Redux State Management</h1>
        <h1>Increment/Decrement counter</h1><h2>[Reload the Page and click the button Now!]</h2>
        <h4>using React and Redux</h4>
        <div className='quantity'>
         <button> <a className='quantity__minus' title='DECREMENT'
          onClick={()=> dispatch(decNumber())}>
         <span>-</span></a></button>
          <input name='quantity' type='text' className='quantity__input' value={myState}/>
         <button> <a className='quantity__plus' title='INCREMENT'
         onClick={()=> dispatch(incNumber())}> <span>+</span></a></button>
        </div>
      </div>
      {/* <Input />
      <CalculationOverview />
      <Store/> */}
      
      <Stori/>
     
    </>
  );
}

export default App;
