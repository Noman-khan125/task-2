import React from 'react';

const enput = () => {
  return (
    <div>
      
    </div>
  );
}

export default enput;
