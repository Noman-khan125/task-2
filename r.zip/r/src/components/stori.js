import React from 'react';

const stori = () => {
  return (
    <div>
      
    </div>
  );
}

export default stori;
