import React from 'react';

const calcualate = () => {
  return (
    <div>
      
    </div>
  );
}

export default calcualate;
